Thank You For Using This Asset！

Documentation Online : https://yuki-chan.net/docbeautifulsky/
	        在线文档 : https://yuki-chan.net/docbeautifulsky/
                      

******      Simple Guidance （English）      ******

1. Choose Panoramic or Cubemap type sky according to your needs.

2. Go to the Materials folder and drag the skybox into your scene or the Lighting Panel.



******       简易引导 （中文）               ******

1.根据你的需求选择Panoramic或者Cubemap类型的天空

2.进入Materials文件夹，将天空盒拖拽到场景中或者Lighting面板中


Have Fun！
Hope these skyboxes can help you create more beautiful scenes！~


Any Questions
---------------------------------
* Website: https://yuki-chan.net
* Support: gamemakeryuki@outlook.com




